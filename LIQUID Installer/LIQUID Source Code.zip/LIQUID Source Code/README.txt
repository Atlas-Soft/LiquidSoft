To modify the code, simply import this folder as a project in a java IDE like eclipse,
then add the included jbox2d_LIQUID.jar to the build path as an external JAR file

To check the javadoc, start in doc\index.html